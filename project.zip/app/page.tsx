// filename: app/page.tsx
"use client"

import React, { useState, useEffect } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { ArrowRight, Upload, Plus, Trash, Check, Phone, User, Download } from 'lucide-react'

interface ClientInfo {
  name: string
  dob: string
  ssn: string
  address: string
  phone: string
  email: string
  dlState: string
  dlIssueDate: string
  dlExpDate: string
  dlNumber: string
  occupation: string
}

interface Dependent {
  id: string
  name: string
  dob: string
  ssn: string
  relationship: string
}

interface BankInfo {
  bankName: string
  accountNumber: string
  routingNumber: string
}

interface UserData {
  email: string
  password: string
  currentStep: number
  filingJointly: boolean
  clientInfo: ClientInfo
  spouseInfo: ClientInfo
  dependents: Dependent[]
  bankInfo: BankInfo
  signature: string
  spouseSignature: string
  lastSaved: string
}

interface UploadedFile {
  name: string
  type: string
  data: string
}

interface DocumentUploads {
  clientDL?: UploadedFile
  spouseDL?: UploadedFile
  lastYearTax?: UploadedFile
  incomeDocuments: UploadedFile[]
  irsPin?: UploadedFile
}

export default function TaxChecklistApp() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [isRegistering, setIsRegistering] = useState(false)
  const [loginEmail, setLoginEmail] = useState('')
  const [loginPassword, setLoginPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [loginError, setLoginError] = useState('')
  const [currentUser, setCurrentUser] = useState<string>('')
  const [showSaveNotification, setShowSaveNotification] = useState(false)
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false)

  const [currentStep, setCurrentStep] = useState(0)
  const [filingJointly, setFilingJointly] = useState(false)
  const [clientInfo, setClientInfo] = useState<ClientInfo>({
    name: '', dob: '', ssn: '', address: '', phone: '', email: '',
    dlState: '', dlIssueDate: '', dlExpDate: '', dlNumber: '', occupation: ''
  })
  const [spouseInfo, setSpouseInfo] = useState<ClientInfo>({
    name: '', dob: '', ssn: '', address: '', phone: '', email: '',
    dlState: '', dlIssueDate: '', dlExpDate: '', dlNumber: '', occupation: ''
  })
  const [dependents, setDependents] = useState<Dependent[]>([])
  const [bankInfo, setBankInfo] = useState<BankInfo>({
    bankName: '', accountNumber: '', routingNumber: ''
  })
  const [signature, setSignature] = useState('')
  const [spouseSignature, setSpouseSignature] = useState('')
  const [submitted, setSubmitted] = useState(false)
  const [documentUploads, setDocumentUploads] = useState<DocumentUploads>({
    incomeDocuments: []
  })
  const [incomeSelections, setIncomeSelections] = useState<string[]>([])
  const [adjustmentSelections, setAdjustmentSelections] = useState<{[key: string]: string}>({})
  const [creditSelections, setCreditSelections] = useState<{[key: string]: any}>({})

  const steps = [
    'Welcome',
    'Client Information',
    'Spouse Information',
    'Dependents',
    'Document Uploads',
    'Income Information',
    'Adjustments',
    'Credits & Deductions',
    'Bank Information',
    'Review & Sign'
  ]

  useEffect(() => {
    if (isLoggedIn && currentUser) {
      loadUserData(currentUser)
    }
  }, [isLoggedIn, currentUser])

  useEffect(() => {
    if (isLoggedIn && currentUser) {
      const interval = setInterval(() => {
        saveUserData()
      }, 30000)
      return () => clearInterval(interval)
    }
  }, [isLoggedIn, currentUser, currentStep, filingJointly, clientInfo, spouseInfo, dependents, bankInfo, signature, spouseSignature, documentUploads, incomeSelections, adjustmentSelections, creditSelections])

  const saveUserData = () => {
    if (!currentUser) return

    const userData: UserData = {
      email: currentUser,
      password: localStorage.getItem(`user_${currentUser}_password`) || '',
      currentStep,
      filingJointly,
      clientInfo,
      spouseInfo,
      dependents,
      bankInfo,
      signature,
      spouseSignature,
      lastSaved: new Date().toISOString()
    }

    localStorage.setItem(`user_${currentUser}_data`, JSON.stringify(userData))
    localStorage.setItem(`user_${currentUser}_documents`, JSON.stringify(documentUploads))
    localStorage.setItem(`user_${currentUser}_income`, JSON.stringify(incomeSelections))
    localStorage.setItem(`user_${currentUser}_adjustments`, JSON.stringify(adjustmentSelections))
    localStorage.setItem(`user_${currentUser}_credits`, JSON.stringify(creditSelections))
    setShowSaveNotification(true)
    setTimeout(() => setShowSaveNotification(false), 2000)
  }

  const loadUserData = (email: string) => {
    const savedData = localStorage.getItem(`user_${email}_data`)
    const savedDocuments = localStorage.getItem(`user_${email}_documents`)
    const savedIncome = localStorage.getItem(`user_${email}_income`)
    const savedAdjustments = localStorage.getItem(`user_${email}_adjustments`)
    const savedCredits = localStorage.getItem(`user_${email}_credits`)
    
    if (savedData) {
      const userData: UserData = JSON.parse(savedData)
      setCurrentStep(userData.currentStep || 0)
      setFilingJointly(userData.filingJointly || false)
      setClientInfo(userData.clientInfo || clientInfo)
      setSpouseInfo(userData.spouseInfo || spouseInfo)
      setDependents(userData.dependents || [])
      setBankInfo(userData.bankInfo || bankInfo)
      setSignature(userData.signature || '')
      setSpouseSignature(userData.spouseSignature || '')
    }
    if (savedDocuments) {
      setDocumentUploads(JSON.parse(savedDocuments))
    }
    if (savedIncome) {
      setIncomeSelections(JSON.parse(savedIncome))
    }
    if (savedAdjustments) {
      setAdjustmentSelections(JSON.parse(savedAdjustments))
    }
    if (savedCredits) {
      setCreditSelections(JSON.parse(savedCredits))
    }
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>, field: string) => {
    const file = event.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onloadend = () => {
      const uploadedFile: UploadedFile = {
        name: file.name,
        type: file.type,
        data: reader.result as string
      }

      if (field === 'incomeDocuments') {
        setDocumentUploads(prev => ({
          ...prev,
          incomeDocuments: [...prev.incomeDocuments, uploadedFile]
        }))
      } else {
        setDocumentUploads(prev => ({
          ...prev,
          [field]: uploadedFile
        }))
      }
    }
    reader.readAsDataURL(file)
  }

  const generatePDFContent = () => {
    const currentDate = new Date().toLocaleDateString()
    
    let pdfContent = `
TAX CHECKLIST 2025 - THE BOOKS SOLUTION
Generated: ${currentDate}
Client Email: ${currentUser}

========================================
CLIENT INFORMATION
========================================
Name: ${clientInfo.name}
Date of Birth: ${clientInfo.dob}
SSN: ${clientInfo.ssn}
Address: ${clientInfo.address}
Phone: ${clientInfo.phone}
Email: ${clientInfo.email}
Driver's License State: ${clientInfo.dlState}
Driver's License Number: ${clientInfo.dlNumber}
DL Issue Date: ${clientInfo.dlIssueDate}
DL Expiration Date: ${clientInfo.dlExpDate}
Occupation: ${clientInfo.occupation}

Filing Status: ${filingJointly ? 'Married Filing Jointly' : 'Single'}
`

    if (filingJointly && spouseInfo.name) {
      pdfContent += `
========================================
SPOUSE INFORMATION
========================================
Name: ${spouseInfo.name}
Date of Birth: ${spouseInfo.dob}
SSN: ${spouseInfo.ssn}
Phone: ${spouseInfo.phone}
Email: ${spouseInfo.email}
Driver's License State: ${spouseInfo.dlState}
Driver's License Number: ${spouseInfo.dlNumber}
DL Issue Date: ${spouseInfo.dlIssueDate}
DL Expiration Date: ${spouseInfo.dlExpDate}
Occupation: ${spouseInfo.occupation}
`
    }

    if (dependents.length > 0) {
      pdfContent += `
========================================
DEPENDENTS (${dependents.length})
========================================
`
      dependents.forEach((dep, index) => {
        pdfContent += `
Dependent ${index + 1}:
  Name: ${dep.name}
  Date of Birth: ${dep.dob}
  SSN: ${dep.ssn}
  Relationship: ${dep.relationship}
`
      })
    }

    if (incomeSelections.length > 0) {
      pdfContent += `
========================================
INCOME SOURCES
========================================
${incomeSelections.join('\n')}
`
    }

    if (Object.keys(adjustmentSelections).length > 0) {
      pdfContent += `
========================================
INCOME ADJUSTMENTS
========================================
`
      Object.entries(adjustmentSelections).forEach(([key, value]) => {
        if (value) {
          pdfContent += `${key}: $${value}\n`
        }
      })
    }

    if (Object.keys(creditSelections).length > 0) {
      pdfContent += `
========================================
CREDITS & DEDUCTIONS
========================================
`
      Object.entries(creditSelections).forEach(([key, value]) => {
        if (value) {
          pdfContent += `${key}: ${typeof value === 'object' ? JSON.stringify(value) : value}\n`
        }
      })
    }

    if (bankInfo.bankName) {
      pdfContent += `
========================================
BANK INFORMATION (For Refund)
========================================
Bank Name: ${bankInfo.bankName}
Account Number: ${bankInfo.accountNumber}
Routing Number: ${bankInfo.routingNumber}
`
    }

    pdfContent += `
========================================
SIGNATURES
========================================
Taxpayer Signature: ${signature}
Date: ${currentDate}
`

    if (filingJointly && spouseSignature) {
      pdfContent += `
Spouse Signature: ${spouseSignature}
Date: ${currentDate}
`
    }

    pdfContent += `
========================================
DOCUMENTS ATTACHED
========================================
`
    if (documentUploads.clientDL) pdfContent += `- Client Driver's License: ${documentUploads.clientDL.name}\n`
    if (documentUploads.spouseDL) pdfContent += `- Spouse Driver's License: ${documentUploads.spouseDL.name}\n`
    if (documentUploads.lastYearTax) pdfContent += `- Last Year's Tax Return: ${documentUploads.lastYearTax.name}\n`
    if (documentUploads.incomeDocuments.length > 0) {
      pdfContent += `- Income Documents (${documentUploads.incomeDocuments.length} files):\n`
      documentUploads.incomeDocuments.forEach(doc => {
        pdfContent += `  * ${doc.name}\n`
      })
    }
    if (documentUploads.irsPin) pdfContent += `- IRS PIN Letter: ${documentUploads.irsPin.name}\n`

    return pdfContent
  }

  const downloadPDF = () => {
    const content = generatePDFContent()
    const blob = new Blob([content], { type: 'text/plain' })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `Tax_Checklist_2025_${clientInfo.name.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    window.URL.revokeObjectURL(url)
  }

  const handleSubmit = async () => {
    setIsGeneratingPDF(true)
    
    const pdfContent = generatePDFContent()
    
    saveUserData()
    
    const blob = new Blob([pdfContent], { type: 'text/plain' })
    const fileName = `Tax_Checklist_2025_${clientInfo.name.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.txt`
    
    localStorage.setItem('pendingSubmission', JSON.stringify({
      fileName,
      content: pdfContent,
      clientName: clientInfo.name,
      clientEmail: currentUser,
      documents: documentUploads
    }))
    
    setTimeout(() => {
      setIsGeneratingPDF(false)
      setSubmitted(true)
    }, 2000)
  }

  const handleLogin = () => {
    setLoginError('')
    
    if (!loginEmail || !loginPassword) {
      setLoginError('Please enter both email and password')
      return
    }

    const savedPassword = localStorage.getItem(`user_${loginEmail}_password`)
    
    if (!savedPassword) {
      setLoginError('No account found with this email. Please register.')
      return
    }

    if (savedPassword !== loginPassword) {
      setLoginError('Incorrect password')
      return
    }

    setCurrentUser(loginEmail)
    setIsLoggedIn(true)
  }

  const handleRegister = () => {
    setLoginError('')

    if (!loginEmail || !loginPassword || !confirmPassword) {
      setLoginError('Please fill in all fields')
      return
    }

    if (loginPassword !== confirmPassword) {
      setLoginError('Passwords do not match')
      return
    }

    if (loginPassword.length < 6) {
      setLoginError('Password must be at least 6 characters')
      return
    }

    const existingUser = localStorage.getItem(`user_${loginEmail}_password`)
    if (existingUser) {
      setLoginError('An account with this email already exists')
      return
    }

    localStorage.setItem(`user_${loginEmail}_password`, loginPassword)
    setCurrentUser(loginEmail)
    setIsLoggedIn(true)
    setIsRegistering(false)
  }

  const handleLogout = () => {
    saveUserData()
    setIsLoggedIn(false)
    setCurrentUser('')
    setLoginEmail('')
    setLoginPassword('')
    setConfirmPassword('')
  }

  const addDependent = () => {
    setDependents([...dependents, {
      id: Date.now().toString(),
      name: '',
      dob: '',
      ssn: '',
      relationship: ''
    }])
  }

  const removeDependent = (id: string) => {
    setDependents(dependents.filter(dep => dep.id !== id))
  }

  const updateDependent = (id: string, field: keyof Dependent, value: string) => {
    setDependents(dependents.map(dep => 
      dep.id === id ? { ...dep, [field]: value } : dep
    ))
  }

  const toggleIncomeSelection = (income: string) => {
    setIncomeSelections(prev => 
      prev.includes(income) 
        ? prev.filter(i => i !== income)
        : [...prev, income]
    )
  }

  const renderLogo = () => (
    <div className="flex flex-col items-center justify-center py-8">
      <div className="relative w-32 h-32 mb-6">
        <svg viewBox="0 0 200 200" className="w-full h-full">
          <defs>
            <linearGradient id="bookGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#7BB241" />
              <stop offset="100%" stopColor="#2C5F2D" />
            </linearGradient>
          </defs>
          
          <path
            d="M 40 60 Q 40 50 50 50 L 95 50 L 95 140 Q 95 145 90 145 L 50 145 Q 40 145 40 135 Z"
            fill="url(#bookGradient)"
          />
          <path
            d="M 105 50 L 150 50 Q 160 50 160 60 L 160 135 Q 160 145 150 145 L 110 145 Q 105 145 105 140 Z"
            fill="url(#bookGradient)"
          />
          
          <rect x="98" y="50" width="4" height="95" fill="#1F3A1F" opacity="0.3"/>
          
          <path
            d="M 70 110 L 80 95 L 90 105 L 100 85 L 110 95 L 120 75 L 130 85"
            stroke="white"
            strokeWidth="4"
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          
          <path
            d="M 130 85 L 125 90 M 130 85 L 135 90"
            stroke="white"
            strokeWidth="4"
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </div>
      <div className="text-center">
        <div className="text-xl text-[#2C3E21] font-normal mb-1">The</div>
        <div className="text-5xl text-[#2C3E21] font-bold leading-none mb-1">Books</div>
        <div className="text-5xl text-[#1F3550] font-bold leading-none">Solution</div>
      </div>
    </div>
  )

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            {renderLogo()}
            <CardTitle className="text-2xl">
              {isRegistering ? 'Create Account' : 'Client Portal Login'}
            </CardTitle>
            <CardDescription>
              {isRegistering 
                ? 'Register to save your tax information securely' 
                : 'Access your saved tax checklist'}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="loginEmail">Email Address</Label>
              <Input 
                id="loginEmail"
                type="email"
                value={loginEmail}
                onChange={(e) => setLoginEmail(e.target.value)}
                placeholder="your.email@example.com"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="loginPassword">Password</Label>
              <Input 
                id="loginPassword"
                type="password"
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                placeholder="Enter your password"
              />
            </div>
            {isRegistering && (
              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirm Password</Label>
                <Input 
                  id="confirmPassword"
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Confirm your password"
                />
              </div>
            )}
            {loginError && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
                {loginError}
              </div>
            )}
            <Button 
              onClick={isRegistering ? handleRegister : handleLogin}
              className="w-full bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700"
            >
              {isRegistering ? 'Create Account' : 'Login'}
            </Button>
            <div className="text-center">
              <button
                onClick={() => {
                  setIsRegistering(!isRegistering)
                  setLoginError('')
                  setConfirmPassword('')
                }}
                className="text-sm text-blue-600 hover:underline"
              >
                {isRegistering 
                  ? 'Already have an account? Login' 
                  : "Don't have an account? Register"}
              </button>
            </div>
            <div className="bg-blue-50 p-4 rounded-lg mt-4">
              <p className="text-sm text-blue-900">
                <strong>Secure Portal:</strong> Your information is saved locally and encrypted. 
                You can return anytime to continue your tax checklist.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (submitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-2xl">
          <CardHeader className="text-center">
            {renderLogo()}
            <div className="flex justify-center mb-4">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                <Check className="w-8 h-8 text-green-600" />
              </div>
            </div>
            <CardTitle className="text-3xl text-green-700">Tax Checklist Complete!</CardTitle>
            <CardDescription className="text-lg mt-4">
              Your tax information has been compiled. Please submit it securely through our portal.
            </CardDescription>
          </CardHeader>
          <CardContent className="text-center space-y-6">
            <div className="bg-blue-50 p-6 rounded-lg text-left">
              <h3 className="font-semibold text-blue-900 mb-3">Summary of Your Submission:</h3>
              <ul className="space-y-2 text-blue-800 text-sm">
                <li>✓ Client: {clientInfo.name}</li>
                <li>✓ Email: {currentUser}</li>
                {filingJointly && <li>✓ Spouse: {spouseInfo.name}</li>}
                <li>✓ Dependents: {dependents.length}</li>
                <li>✓ Documents: {
                  (documentUploads.clientDL ? 1 : 0) +
                  (documentUploads.spouseDL ? 1 : 0) +
                  (documentUploads.lastYearTax ? 1 : 0) +
                  documentUploads.incomeDocuments.length +
                  (documentUploads.irsPin ? 1 : 0)
                } files attached</li>
              </ul>
            </div>

            <div className="bg-amber-50 p-6 rounded-lg border border-amber-200">
              <h3 className="font-semibold text-amber-900 mb-3">Next Steps:</h3>
              <ol className="text-left space-y-2 text-amber-800 text-sm list-decimal list-inside">
                <li>Download your compiled tax checklist PDF</li>
                <li>Click "Submit to The Books Solution" to securely upload your information</li>
                <li>Our team will review and contact you within 24-48 hours</li>
              </ol>
            </div>

            <div className="space-y-3">
              <Button 
                onClick={downloadPDF}
                variant="outline"
                className="w-full"
                size="lg"
              >
                <Download className="w-5 h-5 mr-2" />
                Download Tax Checklist PDF
              </Button>

              <Button 
                onClick={() => {
                  window.open('https://www.encyro.com/thebookssolution', '_blank')
                }}
                className="w-full bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700"
                size="lg"
              >
                Submit to The Books Solution
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </div>

            <div className="bg-green-50 p-4 rounded-lg">
              <p className="font-semibold text-green-900 mb-2">Need immediate assistance?</p>
              <div className="flex items-center justify-center gap-2 text-green-700">
                <Phone className="w-4 h-4" />
                <span>941-257-9469</span>
              </div>
            </div>

            <div className="flex gap-2 pt-4">
              <Button onClick={handleLogout} variant="outline" className="flex-1">
                Logout
              </Button>
              <Button onClick={() => {
                setSubmitted(false)
                setCurrentStep(0)
              }} variant="outline" className="flex-1">
                Start New Checklist
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (isGeneratingPDF) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardContent className="text-center py-12">
            <div className="flex justify-center mb-6">
              <div className="w-16 h-16 border-4 border-green-600 border-t-transparent rounded-full animate-spin"></div>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Generating Your Tax Checklist</h3>
            <p className="text-gray-600">Please wait while we compile your information...</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      <div className="max-w-4xl mx-auto p-4 pb-24">
        <div className="flex justify-between items-center mb-4">
          {renderLogo()}
          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <User className="w-4 h-4" />
                <span>{currentUser}</span>
              </div>
              {showSaveNotification && (
                <div className="text-xs text-green-600 mt-1">
                  ✓ Progress saved
                </div>
              )}
            </div>
            <Button onClick={handleLogout} variant="outline" size="sm">
              Logout
            </Button>
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg shadow mb-6">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="font-semibold text-gray-900">Your Progress</h3>
              <p className="text-sm text-gray-600">
                Step {currentStep + 1} of {steps.length} - {steps[currentStep]}
              </p>
            </div>
            <Button onClick={saveUserData} variant="outline" size="sm">
              Save Progress
            </Button>
          </div>
        </div>
        
        <div className="mb-8">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-gray-700">
              Step {currentStep + 1} of {steps.length}
            </span>
            <span className="text-sm text-gray-500">{steps[currentStep]}</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-green-500 to-blue-500 h-2 rounded-full transition-all duration-300"
              style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
            />
          </div>
        </div>

        {currentStep === 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl text-center">Welcome Back!</CardTitle>
              <CardDescription className="text-center text-base">
                Continue your 2025 tax return checklist. Your progress has been saved.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-green-50 p-6 rounded-lg">
                <h3 className="font-semibold text-green-900 mb-3">Your Saved Information:</h3>
                <ul className="space-y-2 text-green-800">
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 mt-0.5 flex-shrink-0" />
                    <span>Client information: {clientInfo.name || 'Not started'}</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 mt-0.5 flex-shrink-0" />
                    <span>Dependents: {dependents.length} added</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 mt-0.5 flex-shrink-0" />
                    <span>Filing status: {filingJointly ? 'Joint' : 'Single'}</span>
                  </li>
                </ul>
              </div>

              <div className="bg-blue-50 p-6 rounded-lg">
                <h3 className="font-semibold text-blue-900 mb-3">Instructions:</h3>
                <ul className="space-y-2 text-blue-800">
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 mt-0.5 flex-shrink-0" />
                    <span>Your progress is automatically saved every 30 seconds</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 mt-0.5 flex-shrink-0" />
                    <span>You can logout and return anytime to continue</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 mt-0.5 flex-shrink-0" />
                    <span>Click "Save Progress" button to manually save</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 mt-0.5 flex-shrink-0" />
                    <span>Review all information before final submission</span>
                  </li>
                </ul>
              </div>

              <div className="bg-green-50 p-6 rounded-lg">
                <h3 className="font-semibold text-green-900 mb-3">Need Help?</h3>
                <div className="space-y-2 text-green-800">
                  <div className="flex items-center gap-2">
                    <Phone className="w-5 h-5" />
                    <span className="font-medium">941-257-9469</span>
                  </div>
                  <p className="text-sm">Our tax professionals are available to assist you</p>
                </div>
              </div>

              <div className="bg-amber-50 p-4 rounded-lg border border-amber-200">
                <p className="text-sm text-amber-900">
                  <strong>Security Notice:</strong> All information is encrypted and securely stored. 
                  We comply with all IRS data protection requirements.
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {currentStep === 1 && (
          <Card>
            <CardHeader>
              <CardTitle>Client Information</CardTitle>
              <CardDescription>Please provide your personal information</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name *</Label>
                  <Input 
                    id="name" 
                    value={clientInfo.name}
                    onChange={(e) => setClientInfo({...clientInfo, name: e.target.value})}
                    placeholder="John Doe"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dob">Date of Birth *</Label>
                  <Input 
                    id="dob" 
                    type="date"
                    value={clientInfo.dob}
                    onChange={(e) => setClientInfo({...clientInfo, dob: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="ssn">Social Security Number *</Label>
                  <Input 
                    id="ssn" 
                    value={clientInfo.ssn}
                    onChange={(e) => setClientInfo({...clientInfo, ssn: e.target.value})}
                    placeholder="XXX-XX-XXXX"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number *</Label>
                  <Input 
                    id="phone" 
                    type="tel"
                    value={clientInfo.phone}
                    onChange={(e) => setClientInfo({...clientInfo, phone: e.target.value})}
                    placeholder="(555) 123-4567"
                  />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="email">Email Address *</Label>
                  <Input 
                    id="email" 
                    type="email"
                    value={clientInfo.email}
                    onChange={(e) => setClientInfo({...clientInfo, email: e.target.value})}
                    placeholder="john@example.com"
                  />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="address">Address *</Label>
                  <Textarea 
                    id="address"
                    value={clientInfo.address}
                    onChange={(e) => setClientInfo({...clientInfo, address: e.target.value})}
                    placeholder="123 Main St, City, State, ZIP"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dlState">Driver's License State *</Label>
                  <Input 
                    id="dlState"
                    value={clientInfo.dlState}
                    onChange={(e) => setClientInfo({...clientInfo, dlState: e.target.value})}
                    placeholder="FL"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dlNumber">Driver's License Number *</Label>
                  <Input 
                    id="dlNumber"
                    value={clientInfo.dlNumber}
                    onChange={(e) => setClientInfo({...clientInfo, dlNumber: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dlIssueDate">Issue Date *</Label>
                  <Input 
                    id="dlIssueDate"
                    type="date"
                    value={clientInfo.dlIssueDate}
                    onChange={(e) => setClientInfo({...clientInfo, dlIssueDate: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dlExpDate">Expiration Date *</Label>
                  <Input 
                    id="dlExpDate"
                    type="date"
                    value={clientInfo.dlExpDate}
                    onChange={(e) => setClientInfo({...clientInfo, dlExpDate: e.target.value})}
                  />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="occupation">Occupation *</Label>
                  <Input 
                    id="occupation"
                    value={clientInfo.occupation}
                    onChange={(e) => setClientInfo({...clientInfo, occupation: e.target.value})}
                    placeholder="Software Engineer"
                  />
                </div>
              </div>
              <div className="pt-4 border-t">
                <Label className="flex items-center gap-2 cursor-pointer">
                  <input 
                    type="checkbox" 
                    checked={filingJointly}
                    onChange={(e) => setFilingJointly(e.target.checked)}
                    className="w-4 h-4"
                  />
                  <span>Filing jointly with spouse</span>
                </Label>
              </div>
            </CardContent>
          </Card>
        )}

        {currentStep === 2 && (
          <Card>
            <CardHeader>
              <CardTitle>Spouse Information</CardTitle>
              <CardDescription>
                {filingJointly ? "Please provide your spouse's information" : "Skip this step if not filing jointly"}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {filingJointly ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="spouseName">Full Name *</Label>
                    <Input 
                      id="spouseName"
                      value={spouseInfo.name}
                      onChange={(e) => setSpouseInfo({...spouseInfo, name: e.target.value})}
                      placeholder="Jane Doe"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="spouseDob">Date of Birth *</Label>
                    <Input 
                      id="spouseDob"
                      type="date"
                      value={spouseInfo.dob}
                      onChange={(e) => setSpouseInfo({...spouseInfo, dob: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="spouseSsn">Social Security Number *</Label>
                    <Input 
                      id="spouseSsn"
                      value={spouseInfo.ssn}
                      onChange={(e) => setSpouseInfo({...spouseInfo, ssn: e.target.value})}
                      placeholder="XXX-XX-XXXX"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="spousePhone">Phone Number *</Label>
                    <Input 
                      id="spousePhone"
                      type="tel"
                      value={spouseInfo.phone}
                      onChange={(e) => setSpouseInfo({...spouseInfo, phone: e.target.value})}
                      placeholder="(555) 123-4567"
                    />
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="spouseEmail">Email Address *</Label>
                    <Input 
                      id="spouseEmail"
                      type="email"
                      value={spouseInfo.email}
                      onChange={(e) => setSpouseInfo({...spouseInfo, email: e.target.value})}
                      placeholder="jane@example.com"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="spouseDlState">Driver's License State *</Label>
                    <Input 
                      id="spouseDlState"
                      value={spouseInfo.dlState}
                      onChange={(e) => setSpouseInfo({...spouseInfo, dlState: e.target.value})}
                      placeholder="FL"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="spouseDlNumber">Driver's License Number *</Label>
                    <Input 
                      id="spouseDlNumber"
                      value={spouseInfo.dlNumber}
                      onChange={(e) => setSpouseInfo({...spouseInfo, dlNumber: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="spouseDlIssueDate">Issue Date *</Label>
                    <Input 
                      id="spouseDlIssueDate"
                      type="date"
                      value={spouseInfo.dlIssueDate}
                      onChange={(e) => setSpouseInfo({...spouseInfo, dlIssueDate: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="spouseDlExpDate">Expiration Date *</Label>
                    <Input 
                      id="spouseDlExpDate"
                      type="date"
                      value={spouseInfo.dlExpDate}
                      onChange={(e) => setSpouseInfo({...spouseInfo, dlExpDate: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="spouseOccupation">Occupation *</Label>
                    <Input 
                      id="spouseOccupation"
                      value={spouseInfo.occupation}
                      onChange={(e) => setSpouseInfo({...spouseInfo, occupation: e.target.value})}
                      placeholder="Teacher"
                    />
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <p>Not filing jointly. Click Next to continue.</p>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {currentStep === 3 && (
          <Card>
            <CardHeader>
              <CardTitle>Dependent Information</CardTitle>
              <CardDescription>Add information for each dependent you're claiming</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {dependents.map((dependent, index) => (
                <div key={dependent.id} className="p-4 border rounded-lg space-y-4">
                  <div className="flex justify-between items-center">
                    <h4 className="font-semibold">Dependent {index + 1}</h4>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => removeDependent(dependent.id)}
                    >
                      <Trash className="w-4 h-4 text-red-500" />
                    </Button>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Full Name *</Label>
                      <Input 
                        value={dependent.name}
                        onChange={(e) => updateDependent(dependent.id, 'name', e.target.value)}
                        placeholder="Child's Name"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Date of Birth *</Label>
                      <Input 
                        type="date"
                        value={dependent.dob}
                        onChange={(e) => updateDependent(dependent.id, 'dob', e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Social Security Number *</Label>
                      <Input 
                        value={dependent.ssn}
                        onChange={(e) => updateDependent(dependent.id, 'ssn', e.target.value)}
                        placeholder="XXX-XX-XXXX"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Relationship *</Label>
                      <Input 
                        value={dependent.relationship}
                        onChange={(e) => updateDependent(dependent.id, 'relationship', e.target.value)}
                        placeholder="Son, Daughter, etc."
                      />
                    </div>
                  </div>
                </div>
              ))}
              <Button 
                onClick={addDependent}
                variant="outline"
                className="w-full"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Dependent
              </Button>
            </CardContent>
          </Card>
        )}

        {currentStep === 4 && (
          <Card>
            <CardHeader>
              <CardTitle>Document Uploads</CardTitle>
              <CardDescription>Upload required documents (photos or PDFs)</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="p-4 border-2 border-dashed rounded-lg">
                  <Label className="block mb-2 font-semibold">Driver's License (Client) *</Label>
                  <input
                    type="file"
                    accept="image/*,.pdf"
                    onChange={(e) => handleFileUpload(e, 'clientDL')}
                    className="hidden"
                    id="clientDL"
                  />
                  <label htmlFor="clientDL">
                    <Button variant="outline" className="w-full" type="button" onClick={() => document.getElementById('clientDL')?.click()}>
                      <Upload className="w-4 h-4 mr-2" />
                      {documentUploads.clientDL ? documentUploads.clientDL.name : 'Upload Document'}
                    </Button>
                  </label>
                  <p className="text-xs text-gray-500 mt-2">Accepted: JPG, PNG, PDF (Max 5MB)</p>
                </div>

                {filingJointly && (
                  <div className="p-4 border-2 border-dashed rounded-lg">
                    <Label className="block mb-2 font-semibold">Driver's License (Spouse) *</Label>
                    <input
                      type="file"
                      accept="image/*,.pdf"
                      onChange={(e) => handleFileUpload(e, 'spouseDL')}
                      className="hidden"
                      id="spouseDL"
                    />
                    <label htmlFor="spouseDL">
                      <Button variant="outline" className="w-full" type="button" onClick={() => document.getElementById('spouseDL')?.click()}>
                        <Upload className="w-4 h-4 mr-2" />
                        {documentUploads.spouseDL ? documentUploads.spouseDL.name : 'Upload Document'}
                      </Button>
                    </label>
                    <p className="text-xs text-gray-500 mt-2">Accepted: JPG, PNG, PDF (Max 5MB)</p>
                  </div>
                )}

                <div className="p-4 border-2 border-dashed rounded-lg">
                  <Label className="block mb-2 font-semibold">Last Year's Tax Return</Label>
                  <input
                    type="file"
                    accept=".pdf"
                    onChange={(e) => handleFileUpload(e, 'lastYearTax')}
                    className="hidden"
                    id="lastYearTax"
                  />
                  <label htmlFor="lastYearTax">
                    <Button variant="outline" className="w-full" type="button" onClick={() => document.getElementById('lastYearTax')?.click()}>
                      <Upload className="w-4 h-4 mr-2" />
                      {documentUploads.lastYearTax ? documentUploads.lastYearTax.name : 'Upload Document'}
                    </Button>
                  </label>
                  <p className="text-xs text-gray-500 mt-2">Upload your 2024 tax return if available</p>
                </div>

                <div className="p-4 border-2 border-dashed rounded-lg">
                  <Label className="block mb-2 font-semibold">Income Documents (W-2, 1099, etc.)</Label>
                  <input
                    type="file"
                    accept="image/*,.pdf"
                    multiple
                    onChange={(e) => handleFileUpload(e, 'incomeDocuments')}
                    className="hidden"
                    id="incomeDocuments"
                  />
                  <label htmlFor="incomeDocuments">
                    <Button variant="outline" className="w-full" type="button" onClick={() => document.getElementById('incomeDocuments')?.click()}>
                      <Upload className="w-4 h-4 mr-2" />
                      Upload Documents ({documentUploads.incomeDocuments.length} files)
                    </Button>
                  </label>
                  {documentUploads.incomeDocuments.length > 0 && (
                    <div className="mt-2 space-y-1">
                      {documentUploads.incomeDocuments.map((doc, idx) => (
                        <p key={idx} className="text-xs text-gray-600">✓ {doc.name}</p>
                      ))}
                    </div>
                  )}
                  <p className="text-xs text-gray-500 mt-2">You can upload multiple files</p>
                </div>

                <div className="p-4 border-2 border-dashed rounded-lg">
                  <Label className="block mb-2 font-semibold">IRS PIN Letter (if applicable)</Label>
                  <input
                    type="file"
                    accept="image/*,.pdf"
                    onChange={(e) => handleFileUpload(e, 'irsPin')}
                    className="hidden"
                    id="irsPin"
                  />
                  <label htmlFor="irsPin">
                    <Button variant="outline" className="w-full" type="button" onClick={() => document.getElementById('irsPin')?.click()}>
                      <Upload className="w-4 h-4 mr-2" />
                      {documentUploads.irsPin ? documentUploads.irsPin.name : 'Upload Document'}
                    </Button>
                  </label>
                  <p className="text-xs text-gray-500 mt-2">Only if you received an IRS PIN letter</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {currentStep === 5 && (
          <Card>
            <CardHeader>
              <CardTitle>Income Information</CardTitle>
              <CardDescription>Select all income sources that apply to you</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                {[
                  'W-2 Forms (Employment Income)',
                  '1099-MISC (Miscellaneous Income)',
                  '1099-NEC (Non-Employee Compensation)',
                  '1099-INT (Interest Income)',
                  '1099-DIV (Dividend Income)',
                  '1099-B (Proceeds from Broker Transactions)',
                  '1099-K (Payment Card and Third Party Network Transactions)',
                  '1099-R (Retirement Distributions)',
                  '1099-SSA (Social Security Benefits)',
                  '1099-G (Government Payments)',
                  'Rental Property Income',
                  'Capital Gains/Losses',
                  'Trading Activity (Traditional/Virtual Currency)'
                ].map((income) => (
                  <Label key={income} className="flex items-center gap-2 cursor-pointer p-3 border rounded-lg hover:bg-gray-50">
                    <input 
                      type="checkbox" 
                      className="w-4 h-4"
                      checked={incomeSelections.includes(income)}
                      onChange={() => toggleIncomeSelection(income)}
                    />
                    <span>{income}</span>
                  </Label>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {currentStep === 6 && (
          <Card>
            <CardHeader>
              <CardTitle>Income Adjustments</CardTitle>
              <CardDescription>Select adjustments that apply to reduce your taxable income</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                {[
                  'IRA Contributions',
                  'SEP IRA Contributions',
                  'Medical Savings Account (HSA/MSA)',
                  'Self-Employed Health Insurance',
                  'Student Loan Interest',
                  'Tuition and Fees',
                  'Self-Employed Pension Plans'
                ].map((adjustment) => (
                  <div key={adjustment} className="p-3 border rounded-lg">
                    <Label className="flex items-center gap-2 cursor-pointer mb-2">
                      <input 
                        type="checkbox" 
                        className="w-4 h-4"
                        checked={!!adjustmentSelections[adjustment]}
                        onChange={(e) => {
                          if (!e.target.checked) {
                            const newSelections = {...adjustmentSelections}
                            delete newSelections[adjustment]
                            setAdjustmentSelections(newSelections)
                          } else {
                            setAdjustmentSelections({...adjustmentSelections, [adjustment]: ''})
                          }
                        }}
                      />
                      <span>{adjustment}</span>
                    </Label>
                    {adjustmentSelections[adjustment] !== undefined && (
                      <Input 
                        placeholder="Amount contributed/paid" 
                        className="mt-2"
                        value={adjustmentSelections[adjustment] || ''}
                        onChange={(e) => setAdjustmentSelections({...adjustmentSelections, [adjustment]: e.target.value})}
                      />
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {currentStep === 7 && (
          <Card>
            <CardHeader>
              <CardTitle>Credits & Deductions</CardTitle>
              <CardDescription>Select credits and deductions you qualify for</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="p-3 border rounded-lg">
                  <Label className="flex items-center gap-2 cursor-pointer mb-2">
                    <input 
                      type="checkbox" 
                      className="w-4 h-4"
                      checked={!!creditSelections['Childcare Expenses']}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setCreditSelections({...creditSelections, 'Childcare Expenses': {}})
                        } else {
                          const newSelections = {...creditSelections}
                          delete newSelections['Childcare Expenses']
                          setCreditSelections(newSelections)
                        }
                      }}
                    />
                    <span>Childcare Expenses</span>
                  </Label>
                  {creditSelections['Childcare Expenses'] && (
                    <div className="space-y-2 mt-2">
                      <Input placeholder="Provider name" />
                      <Input placeholder="Provider tax ID" />
                      <Input placeholder="Amount paid" />
                    </div>
                  )}
                </div>
                <div className="p-3 border rounded-lg">
                  <Label className="flex items-center gap-2 cursor-pointer mb-2">
                    <input 
                      type="checkbox" 
                      className="w-4 h-4"
                      checked={!!creditSelections['Mortgage Interest']}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setCreditSelections({...creditSelections, 'Mortgage Interest': ''})
                        } else {
                          const newSelections = {...creditSelections}
                          delete newSelections['Mortgage Interest']
                          setCreditSelections(newSelections)
                        }
                      }}
                    />
                    <span>Mortgage Interest</span>
                  </Label>
                  {creditSelections['Mortgage Interest'] !== undefined && (
                    <Input 
                      placeholder="Amount paid" 
                      className="mt-2"
                      value={creditSelections['Mortgage Interest'] || ''}
                      onChange={(e) => setCreditSelections({...creditSelections, 'Mortgage Interest': e.target.value})}
                    />
                  )}
                </div>
                <div className="p-3 border rounded-lg">
                  <Label className="flex items-center gap-2 cursor-pointer mb-2">
                    <input 
                      type="checkbox" 
                      className="w-4 h-4"
                      checked={!!creditSelections['Home Business Expenses']}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setCreditSelections({...creditSelections, 'Home Business Expenses': ''})
                        } else {
                          const newSelections = {...creditSelections}
                          delete newSelections['Home Business Expenses']
                          setCreditSelections(newSelections)
                        }
                      }}
                    />
                    <span>Home Business Expenses</span>
                  </Label>
                  {creditSelections['Home Business Expenses'] !== undefined && (
                    <Textarea 
                      placeholder="Describe expenses" 
                      className="mt-2"
                      value={creditSelections['Home Business Expenses'] || ''}
                      onChange={(e) => setCreditSelections({...creditSelections, 'Home Business Expenses': e.target.value})}
                    />
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {currentStep === 8 && (
          <Card>
            <CardHeader>
              <CardTitle>Bank Account Information</CardTitle>
              <CardDescription>For direct deposit of your tax refund</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-blue-50 p-4 rounded-lg mb-4">
                <p className="text-sm text-blue-900">
                  <strong>Secure Information:</strong> Your bank details are encrypted and used only for refund processing.
                </p>
              </div>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="bankName">Bank Name *</Label>
                  <Input 
                    id="bankName"
                    value={bankInfo.bankName}
                    onChange={(e) => setBankInfo({...bankInfo, bankName: e.target.value})}
                    placeholder="Chase Bank"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="accountNumber">Account Number *</Label>
                  <Input 
                    id="accountNumber"
                    value={bankInfo.accountNumber}
                    onChange={(e) => setBankInfo({...bankInfo, accountNumber: e.target.value})}
                    placeholder="XXXXXXXXXXXX"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="routingNumber">Routing Number *</Label>
                  <Input 
                    id="routingNumber"
                    value={bankInfo.routingNumber}
                    onChange={(e) => setBankInfo({...bankInfo, routingNumber: e.target.value})}
                    placeholder="XXXXXXXXX"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {currentStep === 9 && (
          <Card>
            <CardHeader>
              <CardTitle>Review & Sign</CardTitle>
              <CardDescription>Review your information and provide digital signatures</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-amber-50 p-4 rounded-lg border border-amber-200">
                <h3 className="font-semibold text-amber-900 mb-2">Declaration</h3>
                <p className="text-sm text-amber-800">
                  Under penalties of perjury, I declare that I have examined this return and accompanying schedules and statements, 
                  and to the best of my knowledge and belief, they are true, correct, and complete. Declaration of preparer 
                  (other than taxpayer) is based on all information of which preparer has any knowledge.
                </p>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="signature">Taxpayer Signature *</Label>
                  <Input 
                    id="signature"
                    value={signature}
                    onChange={(e) => setSignature(e.target.value)}
                    placeholder="Type your full name"
                  />
                  <p className="text-xs text-gray-500">By typing your name, you are providing a legal signature</p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="signatureDate">Date *</Label>
                  <Input 
                    id="signatureDate"
                    type="date"
                  />
                </div>
              </div>

              {filingJointly && (
                <div className="space-y-4 pt-4 border-t">
                  <h3 className="font-semibold">Spouse Signature</h3>
                  <div className="space-y-2">
                    <Label htmlFor="spouseSignature">Spouse Signature *</Label>
                    <Input 
                      id="spouseSignature"
                      value={spouseSignature}
                      onChange={(e) => setSpouseSignature(e.target.value)}
                      placeholder="Type your full name"
                    />
                    <p className="text-xs text-gray-500">By typing your name, you are providing a legal signature</p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="spouseSignatureDate">Date *</Label>
                    <Input 
                      id="spouseSignatureDate"
                      type="date"
                    />
                  </div>
                </div>
              )}

              <div className="bg-green-50 p-4 rounded-lg">
                <h3 className="font-semibold text-green-900 mb-2">Summary</h3>
                <div className="space-y-1 text-sm text-green-800">
                  <p>✓ Client information completed</p>
                  {filingJointly && <p>✓ Spouse information completed</p>}
                  <p>✓ {dependents.length} dependent(s) added</p>
                  <p>✓ {
                    (documentUploads.clientDL ? 1 : 0) +
                    (documentUploads.spouseDL ? 1 : 0) +
                    (documentUploads.lastYearTax ? 1 : 0) +
                    documentUploads.incomeDocuments.length +
                    (documentUploads.irsPin ? 1 : 0)
                  } documents uploaded</p>
                  <p>✓ {incomeSelections.length} income sources selected</p>
                  <p>✓ Bank information provided</p>
                </div>
              </div>

              <Button 
                onClick={handleSubmit}
                className="w-full bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700"
                size="lg"
              >
                Generate PDF & Submit Tax Checklist
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </CardContent>
          </Card>
        )}

        <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg p-4">
          <div className="max-w-4xl mx-auto flex justify-between gap-4">
            <Button 
              variant="outline"
              onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
              disabled={currentStep === 0}
              className="flex-1"
            >
              Previous
            </Button>
            <Button 
              onClick={() => setCurrentStep(Math.min(steps.length - 1, currentStep + 1))}
              disabled={currentStep === steps.length - 1}
              className="flex-1 bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700"
            >
              Next
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

// END OF FILE